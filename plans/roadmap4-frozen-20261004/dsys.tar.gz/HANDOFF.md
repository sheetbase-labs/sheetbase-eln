# DSYS05 frozen task-only WIP — 4 October 2026

## Delivery and integrity

All nine included source/test/doc files match the parent checkpoint
`2c7d319442fa7436f853d85828b5c8db0f6a9bd2` byte-for-byte. That checkpoint is
on the fetched remote `origin/GWP/roadmap-4-shell` in
`sheetbase-labs/sheetbase-eln`. No separate branch push is needed for these
files. This packet is a frozen handoff, not task acceptance or new code.

The source worktree is `/home/user/workspace/dsys05-set0323`, detached at
`b589e4175cf156890a20c79f28ee94e322f2447b`, with accepted 0324/0325 authority
overlaid and owned DSYS05 source retained. No migrations, journal, secrets,
environment files, credentials, node_modules or unrelated UI files are included.
Verify the extracted packet with `sha256sum -c SHA256SUMS`.

Current `src/db/seed/design.ts` SHA256:
`2aa68895680f9227ed2c42f9e9bb8cdfe2b7d2e593575ca114c2d11ed033464b`.

## Current source contract

- Project access is established before scientific writes using declared semantic
  leads and explicit principal flags. Mei has View+Edit+Review for AAV9. No
  temporary or broad Gareth grants were introduced.
- Gareth remains the explicitly required DS-0298 creator. Fresh unspecified
  DS-0290/DS-0305 creators use permitted lead Mei. Existing history is retained.
- Dataset links use `api.create_record_link` with the actual permitted actor,
  null records-only FK, scoped existing-link lookup and native provenance.
- Results links look up the existing `VCD by day` analysis view by exact
  workspace/owner/name and call
  `api.create_record_link(sourceUUID,'analysis',actualDisplayId,'analysis')`
  once. No composite expansion that repeats volatile invocation is used.
  Existing figures/history remain untouched; no fabricated audit payload.
- The three scenario preparations retain distinct disposable databases and
  genuine authority. They are not default-seed state rewrites or visual acceptance.
- The checker uses family-aware/scoped exact identities, fails on unmatched
  identifiers and has completed-fixture/unmatched negative controls. It is an
  identifier gate, not all-visible-values coverage.

## Executed verification and its limits

Current source `2aa68895...`: TypeScript, source ESLint, Prettier and the
canonical Results incremental patch dry-apply passed. No full runtime run was
performed after that Results conversion: parent explicitly holds it for verified
0326 acceptance.

The enclosed runtime evidence was executed on preceding source
`ac6dfdc7ba7710d5b0dc9582a8f024e7d0d5437fc4bc00ed82bb20bd54e525db`
against exact accepted 0324/0325 authority:

- Access + lookups: 2 DB suites / 5 tests PASS, 30.58 seconds. Includes ten
  exact Dataset links, actor-sensitive provenance, null FKs and replay retaining
  links and audit events.
- All four owned DB suites: 2 files passed / 2 failed; 5 tests passed / 2 failed,
  49.99 seconds. Credentials and coverage stop at `seedDesignResults` analysis
  citation; their later assertions are not independently passed here.
- `pnpm db:fresh --design` against validated loopback `sheetbase_test`: supported
  migrations PASS, seed EXIT 1. `pnpm db:seed:design` reseed also EXIT 1 at the
  same Results link. Seed logs identify completed steps, not the failing step.
- Native authenticated proof: Gareth can View/Edit EXP-0142 and read his actual
  same-workspace AN-0001 analysis view; 0325 target resolver returns false and
  even canonical `create_record_link` returns 42501. The resolver supported
  Dataset/record identities but not analysis-view identities.
- Partial-seed identifier gate: 515/971 matched, 456 misses, EXIT 1. This is an
  incomplete seed checkpoint, not regression from the earlier complete-seed
  595/971 checkpoint and not all-values evidence. Original acceptance remains unmet.

## Pending authority and human decisions

EXP thread `T-01a10826-7019-700b-a630-fc8b8df1bead` remains sole 0326 writer
until the next coordinator independently accepts its exact packet. All other
schema writers are queued. Do not run full fresh/reseed before that acceptance.

EXP reports (not independently executed by DSYS05) that canonical analysis links
now pass with same-workspace live analysis authority, readable spec/provenance,
null FK and forged/foreign/unknown/direct-write denials. Native link trigger owns
actor/record/project/target audit. It also reports native 125→150 Dataset changes,
immutable replay and genuine current→stale analysis evidence passing. Worker
explicit Dataset-row revision linkage remains under validation. Do not seed causal
effects before its verified contract is handed off.

The authoritative operation-clock proposal is still unresolved. Original
September signing/delivery/invitation dates cannot be supplied honestly by a
single fixed 25 September 09:40 clock through unchanged live authorities. Owner
approval of isolated forward-only scenario timelines remains a human blocker;
there is no approved product clock/UUID override or evidence rewrite.

DSYS05 all-values, immutable-original parity and whole-task closure remain open.
Do not remove a figure, weaken policy, invent grants/credentials/events/receipts,
rewrite historical signatures or modify reference canvases to make an exit green.

## Resume within existing scope

After independent parent acceptance of exact 0326, use the current committed
parent source and run the four owned DB suites plus the scenario suite as
appropriate. Run full isolated documented fresh/reseed, verify native Results
link provenance/replay and retain real negative authorization controls. Re-run
the complete identifier gate and continue original all-values exits only within
already-started DSYS05. Report further canonical feature or clock blockers rather
than bypassing them. No new task or competing migration is authorized.
