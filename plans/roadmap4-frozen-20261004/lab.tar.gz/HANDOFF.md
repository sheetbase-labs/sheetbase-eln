# LAB-07 frozen WIP packet

Frozen on 4 October 2026 after fresh checks at 21:08–21:11 UTC.
This is incomplete original Roadmap 4 LAB-07 work, not a completion claim.

## Source and integration boundary

- Checkout: `/home/user/workspace/lab07`, detached at
  `6f56979970a5107a0bb07e9dac0126b158a2943e`, with the exact parent 0319 overlay.
- Parent overlay: `parent-current-0319.tar.gz`, SHA-256
  `ebe2a4a02457ec1b1c62a9558177778a6c481945a5bcf43d072d22533fc0fcd0`.
- Pristine imported reference: `/home/user/workspace/lab07-reference`.
- Ten task-only source files retain their repository-relative paths.
  `SHA256SUMS` lists each source hash. No secrets or environment files are included.
- Sources are byte-identical to the previous `lab07-native-checkpoint.tar.gz`,
  SHA-256 `a71284ea49fded1046d2d23a761c41b9b53cc64fc5354823e6f00703cbd87e5c`.
- Schema, every migration and journal file, and the generated route tree remain
  byte-identical to the imported reference. No schema slot has been released.
- The parent reports integrated commits through `2c7d3194`. This packet has not
  been tested against that newer integrated head. The next coordinator must
  compare sources before extraction and independently accept integration.

## Implemented increment

The protocol detail route renders canonical rich text rather than flattening
lists and scientific marks. Procedure definitions retain block IDs and order.
Live content is labelled Working document, with loading, read-error and
non-protocol-record handling. URL state uses `section`, separate from the parent
list's `tab`. A native disposable-database check confirmed Template selection
survives reload with `section=template` and the protocol template table.

The prepared per-version training component filters acknowledgements by exact
revision, offers only self-acknowledgement, retains supplied dates and handles
pending, failure, repeat and unavailable states. It is not wired to the absent
server contract. Storybook fixtures are explicitly synthetic, not historical
author, reviewer, QA or training evidence.

## Fresh verification

- `pnpm test src/components/v3/protocols src/lib/controlled-protocols.test.ts
  src/lib/protocol-materials.test.ts
  src/components/notebook/protocol-material-blocks.test.tsx`: 22 passed in five files.
- `pnpm typecheck`: passed.
- Targeted ESLint for protocol components, detail route and controlled-protocol
  client/tests: passed.
- Targeted Prettier check for those files, the contract reference and DB test:
  passed.
- `pnpm build`: passed, client built in 8.47 seconds and SSR in 7.59 seconds.
- `pnpm test:db tests/db/controlled-protocols.test.ts`: nine failed, intentionally
  red. Baseline migrations and fixtures succeed. The contract catalogue reports
  absent versions, acknowledgements, associations and helper functions. The
  remaining cases fail because `api.create_protocol_version` does not exist.

Earlier rendered checks inspected the native working-document fixture and
light, dark, narrow, invalid-document, failed-acknowledgement, pending and
unavailable component states. Keyboard Tab focused the acknowledgement action.
These are rendering and interaction checks, not endpoint or original-board
acceptance. Evidence is retained in the originating thread's
`.amp/in/artifacts/`. No canvas, renderer, harness or acceptance threshold changed.

## Agreed ownership and pending exits

LAB-07 owns `protocol_versions`, with `id = revisions.id`, and creation of the
minimal `project_protocols` relation. The composite association foreign key is
`(protocol_version_id, protocol_record_id, workspace_id)` with one current pin
per project and protocol. PROJ-01 retains setter, copy RPC and UI ownership.

Agreed server helpers are `internal.protocol_version_is_eligible(uuid,boolean)`
for lifecycle-only eligibility and
`internal.assert_protocol_start_eligible(uuid,text,uuid)` for lifecycle, owner
acknowledgement, ACL and required project exact-pin enforcement. Approved is not
effective. Effective timestamps and the exact immutable revision are authority.

Protocol approvals reuse `approval_requests` and `approval_request_decisions`.
Protocol-kind guards must enforce author submission, independent technical
review, then independent QA approval. Generic mutation RPC bodies stay shared.
MDL-03 owns its Record Model guards and remains queued. LAB-07 owns the protocol
stage guards. No shared approval-engine duplication is permitted.

Controlled schema and server implementation, exact-version pinning, integrated
start enforcement, acknowledgement endpoint wiring, reminders, periodic review,
deviations, used-by references and all four original screen acceptance exits
remain pending. Existing coarse record training and approval are not completion.

No additional human credential or product-decision blocker is identified.
The coordination blocker is the exact integrated predecessor handoff and explicit
slot release. EXP retains sole 0326 ownership until independently accepted;
all other schema writers remain queued. Do not generate migrations or push the
shared feature branch from this checkout. Parent/new coordinator owns integration,
verification, pushing and whole-task completion records.
