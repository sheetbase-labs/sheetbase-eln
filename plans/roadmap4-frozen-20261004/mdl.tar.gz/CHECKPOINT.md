# MDL03 frozen WIP source checkpoint

Frozen on 4 October 2026 for coordinator handoff. This packet is not whole-task
completion, server acceptance, visual parity, or permission to migrate.

## Source and integration

Source checkout: `/home/user/workspace/mdl03`, detached base
`6f56979970a5107a0bb07e9dac0126b158a2943e`, with the verified parent0319 overlay.
Overlay SHA256: `ebe2a4a02457ec1b1c62a9558177778a6c481945a5bcf43d072d22533fc0fcd0`.
Pristine overlay retained at `/home/user/workspace/mdl03-pristine-0319`.

The packet contains ten owned source/test files plus this checkpoint,
`SHA256SUMS`, and `existing-files.patch`. The patch contains only the four
pre-existing files; the other six files are new. Parent reports integrated work
committed through `2c7d3194` on `GWP/roadmap-4-shell`. Compare hashes before
importing: do not overwrite newer integration edits or duplicate an existing
checkpoint. Verify source contents with `sha256sum -c SHA256SUMS` after extraction.
No schema, migration, journal, tracker, environment file, credentials, or
dependency installation is included. Original local work remains preserved.

## Current work

Native workspace Record Model Versions dispatch uses stable model key at
`/models/<modelKey>/versions`; UUID parameters keep the Dataset path. Client
contracts validate version snapshots and retain canonical field UUID/name and
unknown semantic metadata. Shared approval UI scopes object kind/cache, requires
independent every-named-role approval for Record Models, and does not present
partial approval as publish-ready. Synthetic stories explicitly disclaim server
and Roadmap acceptance.

Prepared contracts:

- `create_record_model_version(p_model_id,p_reason)` returns a draft version.
- `replace_record_model_version_definition(p_version_id,p_expected_revision,p_definition,p_reason)` returns the revised draft.
- `publish_record_model_version(p_version_id)` explicitly publishes after exact-revision approval.
- `upgrade_record_model_record(p_record_id,p_version_id,p_expected_metadata_version,p_reason)` changes the explicit model pin, with no values argument.
- `record_model_version_usage(p_model_id)` returns real created/upgraded counts.

The red initial-pin fixture publishes v1 via separate reviewer and owner
decisions, then calls existing `create_model_record`. It expects the server to
pin the new Record to published v1, never accept a caller-injected pin. Publishing
v2 must leave old pins and values unchanged. Explicit upgrade preserves values,
canonical field identity and Record UUID, and rejects stale metadata revision.
Metadata revision is concurrency control, not model version.

## Test state

Fresh unit run at 21:08 UTC on 4 October: four files, 48 tests passed:

`pnpm exec vitest run src/components/v3/models/record-model-versions.test.tsx src/components/v3/models/model-approval.test.ts src/components/v3/models/models-data.test.ts src/components/v3/models/model-version-impact.test.ts`

Latest DB run at 18:52 UTC on 4 October against the migrated0319 overlay:
`pnpm exec vitest run --config vitest.db.config.ts tests/db/record-model-versions.test.ts`
had five intended failures. Fabricated generic Record Model approval was accepted;
the four other contracts stopped at absent `create_record_model_version`.
Deeper locks/roles/pins assertions therefore remain unexecuted and unproved.

Last owned source ESLint, `pnpm typecheck`, DB contract Prettier, and bounded
`git diff --check` passed. ESLint cannot parse the DB test under the existing
TypeScript project exclusion; this is not claimed as passing DB lint.
Schema and journal were compared byte-for-byte to pristine0319 again at freeze
and are unchanged by this work.

Rendered synthetic Draft/Pending/error states were inspected. Desktop Pending
light/dark axe WCAG AA each returned 23 passes, zero violations. Narrow details
modal returned 25 passes, zero violations; Escape closed it and restored trigger
focus. These are component-only evidence, not integrated browser acceptance or
unchanged full-board DSYS06 parity.

## Pending authority and blockers

No migration slot has been released. EXP retains sole0326 ownership until the
next coordinator independently accepts its packet. MDL stays queued. Exact
integrated schema/journal/migrations and explicit release are required before
server implementation. No separate checkout push is authorised.

Server guards, version storage, true initial pins, explicit upgrades, pinned
Record-detail interpretation, DB/API/integrated browser tests, and original
DSYS06 parity remain incomplete. Historical MDL0019/MDL0012 fixture/date authority
is unresolved; never fabricate approval history or upgrade counts.

SHEET03 needs a genuinely signed Record-bound Sheet before/after the actual pin
upgrade. Preserve Instance IDs/ACL/row anchors and frozen revision_sheet_evidence
and digest. Definition evolution is not that proof. Signing credentials and
frozen evidence are not established in this MDL red fixture.

LAB07 owns protocol-stage guards. MDL plan remains kind-scoped request/decision
BEFORE guards, object-workspace resolution, actual revision stamping and
every-role independence, leaving generic approval mutation bodies unchanged.

Parent owns integration, commits, push and completion tracking. No push, merge,
deployment or completion claim has been made from this checkout.
