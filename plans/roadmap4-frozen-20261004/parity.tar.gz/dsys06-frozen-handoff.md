# DSYS-06 frozen handoff

## Delivery state and scope

Parent pushed the existing task source through [c14fa46e](https://github.com/sheetbase-labs/sheetbase-eln/commit/c14fa46e61b340732cec63285e1a8f752aa2cc40) on `GWP/roadmap-4-shell`. Fetching that branch independently resolved to this exact commit.

There is no undelivered DSYS-06 task-only source change. Eight of the nine parity-owned files match the pushed commit byte-for-byte. Local `playwright.config.ts` lacks the parent's added `testIgnore: 'rev-03-signing.test.ts'` on the auth-free browser project. Retain the pushed addition; do not replace the parent config with this older local copy.

The nine ownership paths are `.github/workflows/ci.yml`, `playwright.config.ts`, `scripts/design-reference.mts`, and `tests/visual/{design-states.ts,parity.spec.ts,state-driver.ts,parity-drift.spec.ts,parity-reporter.ts,design-scenario.mts}`. Product and seed files in this checkout are borrowed measurement inputs, not another source transfer.

Start no new tasks, task threads or migrations. EXP0326 is the sole current schema writer. The next coordinator owns acceptance and serialized slot release. Parent owns integration, verification and pushing. Original parity and keyboard exits remain unwaived.

## Frozen artifacts

The packet contains the previously delivered patches for provenance, not for reapplication to the pushed branch:

- `DSYS-06-parity.patch`: SHA256 `6c40ab20a1385bda5d08d81f013297848d4b85df41b0e82c2c767beb8d9aa4cd`.
- `DSYS-06-native-scenarios.patch`: SHA256 `9358426dce38291efa5b8c605a2f5e06ac84a4e55a7c7cb63c1b83120891e691`.
- `DSYS-06-native-scenarios-evidence.tar.gz`: SHA256 `f85af24f37a05d5e6a112f5362be29ba3a8c381b182a4733e35594897a8b6f10`. This nested archive has the exact native preparation metadata, logs, inspected captures and failure CSV. No traces containing authentication state are included.
- `dsys06-project-activity.log` and `dsys06-Projects-activity-{light,dark}.png`: later unchanged-feed Projects measurement.
- `dsys06-parity-coverage.json`, `dsys06-mismatch-pixels.csv`, `dsys06-parity.log`: historical full-run evidence before the four native mappings.
- `dsys06-unactivated.log`: final fail-closed activation and coverage check.

Do not use the historical full-run report as a current whole-suite result. Do not reapply historical patches to undo parent integration.

## Proven results and limits

Current registry has 44 mapped boards and 82 explicit pending boards. Final unprepared ReviewSign and coverage check failed twice as required: the scenario failed before navigation, and coverage reported 88/252 mapped comparisons and 164 pending comparisons.

The earlier full run had 79 failures and four passes, with 40 mapped boards and 86 pending. Only HelpRecords had a demonstrated both-theme full-board pass in that run. The later eight-test native/control run had four pixel failures and four passes in 42.3 seconds; the passes were HelpRecords and both one-pixel padding controls.

Final native pixel differences at the unchanged 0.001 gate are recorded in `dsys06-scenario-pixels.csv` inside the native evidence archive. The later Projects activity comparison failed at 39530 light and 38985 dark pixels; its separate log and both inspected captures are included in this packet. All these comparisons remain failures.

Native scenario prerequisites and UI assertions passed before screenshot failure. ReviewSign used the exact parent reviewed-and-approved meaning and DialogBody padding with the actual UUID and digest. SettingsSignature verification used the real October operation date and remained uncertified. HomeFirstRun retained real AAV9 Editor access, empty personal activity and actual 2-of-4 progress. Assignment incorrectly completes the project-open step; this remains product-owned.

SignedOut checked the native design actor with browser fetch, activated Account menu Sign out, required POST 200 and the genuine signed-out URL, then checked the browser session was null. Use browser fetch for session assertions: the separate Playwright APIRequest call observed null before sign-out with this local cookie setup and was not sufficient to prove the authenticated browser state.

No browser clock override applies to native scenarios or SignedOut. Ordinary pre-existing record mappings still use the historical browser baseline. Server-clock and historical-evidence authority remain unresolved.

Each disposable native scenario preserved both existing signatures. All three scenario databases and their managed services were disposed after measurement. Strict TypeScript graph checking with repository aliases reported zero diagnostics; Prettier and whitespace checks passed. The parent independently repeated the fail-closed checks. No original exit is closed by these results.

## Existing activation contracts

`tests/visual/design-scenario.mts <ReviewSign|SettingsSignature|HomeFirstRun>` creates one exact loopback disposable database, applies full migrations and the 43-step canonical seed, calls `prepareDesignScenario`, starts dedicated managed app/PostgREST services, runs both themes serially, verifies existing signatures are unchanged and disposes the scenario. This activation runner is orb-local; CI scenario activation is not implemented.

Ordinary registered comparisons run through `tests/visual/parity.spec.ts` and `visitDesignState`. Preserve vendored references, original frame sizes, pinned Chromium and global tolerance. Pending coverage and unprepared scenarios must fail, not skip or become expected failures.

ExpHistory is already registered at `/experiments/EXP-0142/history` as the Gareth fixture actor, 1440 by 1000 in both themes, but only checks record visibility. EXP owner supplied an authentic component-ready marker `[data-history-ready="true"]`, native selection label `Inspect audit entry <sequence>: <action> <subject>`, and a complementary landmark named `Entry details`. A native method-edit event demonstrates that mechanism, not the original selected Load 125-to-150 cell event. The original causal event is absent/unverified. Do not substitute a generic record or folder event, guess a sequence, or activate original selection before immutable event evidence exists.

SettingsMembers and SettingsAccess are registered ordinary states as Gareth, not Fixture Owner. Current parent design seed was inspected: people have name/email but no username assignment; explicit groups and group rules have no design-seed creation. Client portal membership binds Ana and Ben to CL-017 through `client_viewer` plus `clientId`, not an explicit group rule. Post-0323 runtime default-group behaviour was not independently verified here.

ModelVersions and SchemaPending remain pending until real Record Model IDs, version pins and native approval/upgrade evidence exist. Dataset UUID routes and synthetic stories are not substitutes. Protocol states likewise remain pending; a disposable working-document route and synthetic previews do not prove the original controlled version/training states.

The later Projects activity correction was measured without replay. Actual sequence 174 has a null actor and resolves current readable SMP-2231 identity. The browser displays `No recorded actor updated SMP-2231 · Harvest lot HL-0934`. Another real event resolves RPT-2026-0003. Immutable event payload was not rewritten. The unresolved-actor branch was not independently exercised. Worker unit results were not repeated because the local incremental test baseline differed.

Whole gallery boards, the absent Shortcuts skeleton backdrop, and historical date authority remain separate product/reference decisions. Do not crop a single modal into gallery acceptance, fake a loading backdrop, alter dates or scientific values, or manufacture usernames/group membership/recents to match pixels.

## Suggested skills

Load `typescript-best-practices`, `ponytail` and `unslop` for bounded driver work. Load `using-agent-browser` before browser inspection outside the existing Playwright harness. Use `handoff` when transferring this existing task again. Follow repository guidance and canonical knowledge before making acceptance decisions.
