# PROJ-01 frozen source packet

Frozen on 4 October 2026. Original task acceptance remains incomplete.

All ten task source and test files are byte-identical to the pushed parent checkpoint:
https://github.com/sheetbase-labs/sheetbase-eln/commit/2c7d319442fa7436f853d85828b5c8db0f6a9bd2
There is no additional unintegrated source delta in this packet.

The archive contains those ten files, the runnable native timezone reproduction,
this status file, and SHA-256 manifests. No schema, migration, journal, route-tree,
seed, reference, tracker, environment file, or secret is included.

## Verification at freeze

- Focused units: 3 suites, 16 tests pass.
  Command: `pnpm exec vitest run src/components/v3/projects/project-data.test.ts src/components/v3/projects/projects-page.test.tsx 'src/routes/projects/$projectId/settings.test.tsx'`.
- `pnpm typecheck` passes.
- Source ESLint passes for the two activity source files, their tests, the project list route, and the settings route and test.
- Formatting and diff checks passed during the timezone delivery.
- The runnable timezone reproduction was executed against the isolated auth-free app.
  Native API wire was `2026-09-28T23:00:00+00:00` with `Europe/London`.
  Browser DOM showed `Clarification train selected · 29 Sept` without interception.
  The screenshot was inspected. Exactly one generated acceptance task was removed.
- Typed creation, property-retaining edits, and URL/archive browser tests passed previously.
  Parent independently verified its actual service actor. These browser tests were not rerun at freeze.
- Copy contracts remain intentionally pending. The last local run observed six failures
  at the missing `create_project_from_structure` RPC. They were not rerun against the
  new SET checkpoint and must be adapted to the integrated authority before acceptance.

## Original exits still open

- Atomic structure copy using canonical study milestones, explicit member/group rules,
  and canonical protocol version links. Copy no records or evidence.
- Source management, target writer, stale revision, workspace, readable source,
  invalid/suspended principal, and rollback proof against integrated SET/LAB authority.
- Preserve all access flags independently. Never expand a Reviewer label into grants.
- Portal grants require matching current client memberships without group widening.
- Protocol setter/copy integration awaits LAB creation of the minimal canonical relation.
  Copy checks lifecycle eligibility, not training or experiment-start acknowledgement.
- Remaining server archived-readonly and reviewer enforcement.
- Original five Projects boards and create dialog parity remain unaccepted.
  No references, tolerances, dates, or historical feeds were altered to obtain acceptance.
- Full integrated DB/API/browser/axe acceptance and whole-task completion remain pending.

## Ownership at freeze

Parent owns integration, verification, shared branch pushes, and completion recording.
EXP retains sole migration slot 0326. PROJ has no current schema slot.
No new task or migration was started for this packet. There is no human-input blocker.
The next coordinator must independently accept the predecessor baseline and explicitly
release the queued PROJ slot after the existing REV/EXP/MDL/LAB dependencies.

The native reproduction accepts the running auth-free app URL as its first argument.
Its cleanup database must match the app's disposable database. It does not reset seeds.
It fails if an earlier native open milestone prevents the expected inspector label.
