# Frozen REV WIP checkpoint

Baseline: [2c7d319442fa7436f853d85828b5c8db0f6a9bd2](https://github.com/sheetbase-labs/sheetbase-eln/commit/2c7d319442fa7436f853d85828b5c8db0f6a9bd2), on `GWP/roadmap-4-shell`.

The nine source/test files in this archive are exact exports from that committed baseline. The baseline is present on the remote feature branch. There is no remaining REV source delta to apply. All nine match the owner's local work except the Review route: the exported parent route also preserves SHEET's two commentId deep-link additions. Do not replace it with the older owner-local route.

The archive intentionally contains no schema source, SQL migration, journal or snapshot. REV 0324 is integrated and frozen. EXP retains sole 0326 ownership until coordinator acceptance; this packet does not release or reassign any slot. The owner's separate worktrees remain unchanged and uncommitted locally; no shared-branch push was made from them.

## Included scope

- `src/lib/signatures.ts` and test: signature meanings and effective-View witness candidates, with missing flags failing closed and no automatic grants.
- `src/routes/review/$revisionId.tsx` and test: signing/author/witness UI, exact frozen revision scope, preserved comment deep-link plumbing, and bounded inspector overflow repair.
- `tests/browser/rev-03-signing.test.ts`: original native signing/lockout/signout/evidence assertions, real author View+Edit and witness View-only prerequisites, and effective picker assertions.
- `src/lib/client-portal.ts`, PDF renderer and PDF test: immutable signature manifest, nullable stored names, exact IDs/times/meanings/digests, frozen notes/tables/Sheets.
- `tests/db/portal-signature-evidence.test.ts`: populated portal upgrade and immutable evidence/visibility contracts.

`SHA256SUMS` lists the exact nine source-file hashes. This archive is a recovery checkpoint, not a whole-file replacement instruction for newer coordinator work.

## Observed verification

- Owner portal checkpoint: 3 DB suites / 27 tests passed; 10 PDF tests passed. Parent independently reproduced those results and inspected both rendered PDF pages.
- Owner latest Review/signature focused check: 2 suites / 39 tests passed; scoped lint and typecheck passed.
- Parent integrated effective-View picker: native signing 2/2 passed, including unreadable-witness exclusion and an actual owner-mediated View-only grant before the request. Original signing, lockout, signout, exact revision, immutable evidence and request-removal assertions remain.
- Parent final handoff: 9 focused files / 136 tests passed; root typecheck completed with exit 0. These are mixed-suite totals, not REV-only totals.
- Parent authority checkpoint supporting REV: 143 API tests, 66 DB tests / 7 suites, 62 focused units, native signing 2/2, typecheck and no schema drift passed.
- Parent inspector integration: frozen-comment native case 1/1 passed; desktop 1440x1000 containment passed. Export bottom was 807px and Back to inbox began at 820px.
- Owner isolated inspector render: desktop 1440x1000 and actual Details sheet at 390x844 passed executed bounds checks and inspected screenshots; Request changes confirmation opened and Escape returned to Details without a decision write.

## Open acceptance and blockers

- Parent narrow inspector verification is NOT green. The structured rerun completed desktop measurements but failed narrow measurement with `Missing review controls` and exit 1. Earlier attempts reported `Export missing` / `Details panel missing`. The cause remains unverified. Owner isolated narrow success does not replace parent acceptance.
- Original strict four-screen REV parity and formal signature-screen acceptance remain open.
- Production SMTP/IdP acceptance, expanded-meaning whole-task acceptance and hash-chain/nightly verification remain open. Native flow checks alone do not close them.
- Parent deliberately retains known-red dependent contracts: fresh seed/reseed stops at the Analysis-link authority contract; canonical comment search rejects the comment result filter. Fresh-seed, Home and dependent visual acceptance remain open.

No human credentials or approval are currently required for the local REV checkpoint. The next coordinator must preserve the known-red state, finish independent native narrow/parity verification and coordinate the existing serialized queue. This packet makes no task-closure or production-readiness claim.
