# SET-02 native Settings frozen WIP

This is task-only uncommitted WIP, not whole-task acceptance. Parent owns
integration, commits and push. Do not alter migrations/schema/journal; EXP owns
0326. No seed, visual registry, reference, crop or tolerance edits are included.

## Exact source

Seven whole files under `source/`, relative to the repository root. Native
checkout baseline is accepted aa8a9afa9580d8a81c5b88a596d75606a83f38d4, not the
parent's newer integrated tip. Check ownership differences before copying.
`SOURCE-SHA256SUMS` authenticates the packet files, not parent merge results.

- Existing SET UI: `src/routes/settings/access.tsx`, `members.tsx`,
  `members.test.tsx`, `src/components/v3/settings/workspace-groups.tsx`.
- Necessary native mutation repair: `src/lib/data-client.ts` and its test.
- Native interaction regression: `tests/browser/set-02-settings.test.ts`.

Members shows actual groups/training/certification/activity, absent usernames
as absent, and management according to workspace capabilities. Access uses
canonical rule/default/request APIs and independent flags. Groups CRUD uses
canonical RPCs and explains immediate revocation. The selected default group
label no longer calls an arbitrary selected group QA; that non-default label
state remains visually unverified, rather than claimed complete.

Native testing found successful `set_workspace_group_member` returns 204.
The old shared `DataClient.rpc` parsed JSON unconditionally, so it raised an
error and skipped query invalidation after successful mutations. The fix only
accepts 204 without a body; malformed 200 still rejects. The red unit log proves
the original failure. No authority weakening or error suppression is used.

## Executed verification

From `/home/user/workspace/set02-native`:

```sh
pnpm typecheck
pnpm exec vitest run src/lib/data-client.test.ts src/routes/settings/members.test.tsx src/lib/workspace-access.test.ts
pnpm exec eslint src/routes/settings/access.tsx src/routes/settings/members.tsx src/routes/settings/members.test.tsx src/components/v3/settings/workspace-groups.tsx src/lib/data-client.ts src/lib/data-client.test.ts
git diff --check
SHEETBASE_DEV_AUTH_FREE=false CI=true pnpm exec playwright test --project=browser tests/browser/set-02-settings.test.ts --reporter=list --output=test-results/set02-native
```

- Typecheck, source lint and diff-check pass.
- Focused units: 25/25 in three suites.
- Native owner/viewer interactions: 2/2 in 20.5 seconds, no request interception.
  Owner creates a group, changes Anna's explicit membership, creates Edit+View
  without Review/Manage/portal, adds Review independently, removes the rule,
  removes membership and confirms group deletion. Viewer selects the real
  Process Development workspace and cannot manage members, rules or defaults.
- Running ESLint directly on the browser test fails because that path is not
  included in the configured TypeScript ESLint project. Source lint above is
  green; browser execution is not presented as a lint pass.
- Supervised parity app3200 points to this native checkout, auth-free=false,
  real local PostgREST; no shared deployment was changed.

## Red original exits / blockers

Exact owner seed ac6dfdc7ba7710d5b0dc9582a8f024e7d0d5437fc4bc00ed82bb20bd54e525db
was imported unchanged for local verification. It is intentionally EXCLUDED
from this packet: DSYS05 owns it. Fresh migration0325 succeeds; custody and
Dataset link stages advance, then seed Results fails `record_links_target_write`
for analysis citation AN-0001. Thus the local DB is partial, not accepted seed
evidence. DSYS05 independently minimized the same native denied citation.
Parent/current serialized writer must resolve its structured analysis target
contract; SET has not reopened SQL or substituted a records FK or grants.

Original references rendered unchanged with:

```sh
CI=true pnpm design:render SettingsMembers SettingsAccess
SHEETBASE_DEV_AUTH_FREE=false CI=true pnpm exec playwright test --project=parity tests/visual/parity.spec.ts --grep 'Settings(Members|Access) —' --reporter=list,./tests/visual/parity-reporter.ts --output=test-results/set02-parity
```

All four comparisons FAIL original0.001 tolerance on partial seed:
Members light26962 / dark26660 pixels; Access light19415 / dark19343.
Other boards not-run are not acceptance. A preliminary run happened before the
reference render finished and reported absent references; those auto-created
actuals were replaced by the unchanged named reference renderer before the
recorded comparison. References are excluded from this packet.

Fixture gaps remain usernames, full explicit original groups/rules/portal
groups, certification/training/activity and grouped client presentation.
Do not fabricate data or hide real memberships to force parity. Current native
render and dialogs were inspected; they do not establish original parity.
Review images are in the parent thread workspace root `.amp/in/artifacts/`:
`set02-access-rule.png`, `set02-group-removal.png` (2x).

No human credential/authority input is currently needed. The concrete blocker
is serialized product/seed integration and remaining Settings acceptance,
not unavailable external infrastructure. Keep SET-02 open.
