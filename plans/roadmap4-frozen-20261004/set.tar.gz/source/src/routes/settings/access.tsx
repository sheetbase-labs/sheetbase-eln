import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { Button } from '#/components/v3/ui/button'
import { EmptyState } from '#/components/v3/ui/empty-state'
import { Field } from '#/components/v3/ui/input'
import { Muted, Section } from '#/components/v3/ui/layout'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '#/components/v3/ui/dropdown-menu'
import {
  Dialog,
  DialogBody,
  DialogClose,
  DialogContent,
  DialogFooter,
  DialogHeader,
} from '#/components/v3/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '#/components/v3/ui/table'
import { toast } from '#/components/v3/ui/sonner'
import {
  CheckRow,
  SettingsBody,
  SettingsHeader,
} from '#/components/v3/settings/settings-page'
import { createDataClient } from '#/lib/data-client'
import { hasCapability } from '#/lib/capability'
import {
  fetchWorkspaceMemberIdentities,
  fetchProjectSummaries,
} from '#/components/v3/projects/project-data'
import {
  decideProjectAccessRequest,
  fetchProjectAccessRequests,
  fetchProjectAccessDefaults,
  fetchProjectPermissions,
  fetchWorkspaceAccessRules,
  fetchWorkspaceGroups,
  removeProjectAccessRule,
  setProjectAccessRule,
  setProjectAccessDefaults,
  workspaceAccessKeys,
} from '#/lib/workspace-access'
import type {
  ProjectAccessRule,
  ProjectPermissions,
  WorkspaceGroup,
} from '#/lib/workspace-access'

export const Route = createFileRoute('/settings/access')({ component: Access })
const dataClient = createDataClient()
const columns = [
  { key: 'can_edit', label: 'Edit' },
  { key: 'can_review', label: 'Review' },
  { key: 'can_view', label: 'View' },
  { key: 'client_portal', label: 'Client portal' },
] as const

function Access() {
  const { context } = Route.useRouteContext()
  const workspaceId = context.workspace?.id ?? ''
  const canSetDefaults = hasCapability(
    context.workspace?.role,
    'workspace.admin',
  )
  const queryClient = useQueryClient()
  const [dialog, setDialog] = useState<
    { kind: 'add' } | { kind: 'edit'; rule: ProjectAccessRule } | null
  >(null)
  const [projectFilter, setProjectFilter] = useState('')
  const [groupFilter, setGroupFilter] = useState('')
  const rules = useQuery({
    queryKey: workspaceAccessKeys.rules(workspaceId),
    queryFn: () => fetchWorkspaceAccessRules(dataClient),
    enabled: Boolean(workspaceId),
  })
  const groups = useQuery({
    queryKey: workspaceAccessKeys.groups(workspaceId),
    queryFn: () => fetchWorkspaceGroups(dataClient),
    enabled: Boolean(workspaceId),
  })
  const defaults = useQuery({
    queryKey: workspaceAccessKeys.defaults(workspaceId),
    queryFn: () => fetchProjectAccessDefaults(dataClient),
    enabled: Boolean(workspaceId),
  })
  const projects = useQuery({
    queryKey: ['settings-access-projects', workspaceId],
    queryFn: () => fetchProjectSummaries(workspaceId),
    enabled: Boolean(workspaceId),
  })
  const people = useQuery({
    queryKey: ['settings-access-people', workspaceId],
    queryFn: () => fetchWorkspaceMemberIdentities(),
    enabled: Boolean(workspaceId),
  })
  const permissions = useQuery({
    queryKey: [
      'settings-access-permissions',
      workspaceId,
      projects.data?.map((p) => p.id),
    ],
    queryFn: async () =>
      new Map(
        await Promise.all(
          (projects.data ?? []).map(
            async (p) =>
              [p.id, await fetchProjectPermissions(dataClient, p.id)] as const,
          ),
        ),
      ),
    enabled: Boolean(projects.data),
  })
  const requests = useQuery({
    queryKey: workspaceAccessKeys.requests(workspaceId),
    queryFn: () => fetchProjectAccessRequests(dataClient),
    enabled: Boolean(workspaceId),
  })
  const manageableProjects = (projects.data ?? []).filter(
    (p) => permissions.data?.get(p.id)?.can_manage,
  )
  const invalidate = () => {
    void queryClient.invalidateQueries({
      queryKey: workspaceAccessKeys.all(workspaceId),
    })
    void queryClient.invalidateQueries({
      queryKey: ['settings-access-permissions', workspaceId],
    })
    void queryClient.invalidateQueries({ queryKey: ['ui-port', 'projects'] })
  }
  const save = useMutation({
    mutationFn: (input: Parameters<typeof setProjectAccessRule>[1]) =>
      setProjectAccessRule(dataClient, input),
    onSuccess: () => {
      invalidate()
      setDialog(null)
      toast('Access rule saved')
    },
    onError: (error: Error) =>
      toast('Could not save access rule', { description: error.message }),
  })
  const remove = useMutation({
    mutationFn: (id: string) => removeProjectAccessRule(dataClient, id),
    onSuccess: () => {
      invalidate()
      setDialog(null)
      toast('Access rule removed')
    },
    onError: (error: Error) =>
      toast('Could not remove access rule', { description: error.message }),
  })
  const decide = useMutation({
    mutationFn: (input: { requestId: string; approve: boolean }) =>
      decideProjectAccessRequest(dataClient, input),
    onSuccess: () => {
      invalidate()
      toast('Access request decided')
    },
    onError: (error: Error) =>
      toast('Could not decide access request', { description: error.message }),
  })
  const setDefaults = useMutation({
    mutationFn: (groupId: string | null) =>
      setProjectAccessDefaults(dataClient, groupId),
    onSuccess: () => {
      invalidate()
      toast('Project defaults saved')
    },
    onError: (error: Error) =>
      toast('Could not save project defaults', { description: error.message }),
  })
  const pending = (requests.data ?? []).filter(
    (r) =>
      r.status === 'pending' && permissions.data?.get(r.project_id)?.can_manage,
  )
  const visibleProjects = (projects.data ?? []).filter(
    (p) => !projectFilter || p.id === projectFilter,
  )
  return (
    <>
      <SettingsHeader
        title="Project access"
        border={false}
        actions={
          manageableProjects.length ? (
            <Button
              variant="primary"
              icon="plus"
              onClick={() => setDialog({ kind: 'add' })}
            >
              Add rule
            </Button>
          ) : null
        }
      >
        Who can open each project. Roles decide what they can do there.
      </SettingsHeader>
      <div className="flex items-center gap-2 border-y border-border px-4 py-2 md:px-6">
        <DropdownMenu>
          <DropdownMenuTrigger render={<Button size="sm" variant="quiet" />}>
            Project:{' '}
            {projects.data?.find((p) => p.id === projectFilter)?.title ?? 'any'}
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-80 overflow-y-auto">
            <DropdownMenuItem onClick={() => setProjectFilter('')}>
              any
            </DropdownMenuItem>
            {(projects.data ?? []).map((project) => (
              <DropdownMenuItem
                key={project.id}
                onClick={() => setProjectFilter(project.id)}
              >
                {project.title}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <DropdownMenu>
          <DropdownMenuTrigger render={<Button size="sm" variant="quiet" />}>
            Group:{' '}
            {groups.data?.find((g) => g.id === groupFilter)?.name ?? 'any'}
          </DropdownMenuTrigger>
          <DropdownMenuContent className="max-h-80 overflow-y-auto">
            <DropdownMenuItem onClick={() => setGroupFilter('')}>
              any
            </DropdownMenuItem>
            {(groups.data ?? []).map((group) => (
              <DropdownMenuItem
                key={group.id}
                onClick={() => setGroupFilter(group.id)}
              >
                {group.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <div className="shrink-0 overflow-x-auto">
        {rules.isError || projects.isError || permissions.isError ? (
          <SettingsBody>
            <p role="alert">
              Could not load project access. No permissions have changed.
            </p>
            <Button
              onClick={() => {
                void rules.refetch()
                void projects.refetch()
                void permissions.refetch()
              }}
            >
              Retry
            </Button>
          </SettingsBody>
        ) : rules.isPending || projects.isPending ? (
          <SettingsBody>
            <Muted>Loading project access…</Muted>
          </SettingsBody>
        ) : (
          <Table aria-label="Project access matrix">
            <TableHeader>
              <TableRow>
                <TableHead>Project</TableHead>
                {columns.map((c) => (
                  <TableHead key={c.key}>{c.label}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {visibleProjects.map((p) => {
                const projectRules = rules.data.filter(
                  (r) =>
                    r.project_id === p.id &&
                    (!groupFilter || r.group_id === groupFilter),
                )
                return (
                  <TableRow key={p.id}>
                    <TableCell>{p.title}</TableCell>
                    {columns.map((c) => (
                      <TableCell key={c.key}>
                        {projectRules
                          .filter((r) => r[c.key])
                          .map((r, index) => (
                            <span key={r.id}>
                              {index ? ', ' : ''}
                              {permissions.data?.get(p.id)?.can_manage ? (
                                <button
                                  className="text-left hover:underline focus-visible:outline focus-visible:outline-2"
                                  onClick={() =>
                                    setDialog({ kind: 'edit', rule: r })
                                  }
                                >
                                  {r.principal_name}
                                </button>
                              ) : (
                                r.principal_name
                              )}
                            </span>
                          ))}
                        {!projectRules.some((r) => r[c.key]) ? '—' : null}
                      </TableCell>
                    ))}
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        )}
        {!projects.isPending &&
        !projects.isError &&
        visibleProjects.length === 0 ? (
          <SettingsBody>
            <EmptyState
              icon="lock"
              title="No accessible projects"
              body="An explicit project rule is required. Workspace roles do not grant project access."
            />
          </SettingsBody>
        ) : null}
      </div>
      <SettingsBody className="border-t border-border-subtle">
        <Section title="Defaults for new projects">
          {defaults.data ? (
            <div className="flex flex-col gap-2.5">
              <CheckRow
                title="New projects are private to the lead until members are added"
                checked={defaults.data.private_to_lead}
                disabled
                onCheckedChange={() => {}}
              />
              <CheckRow
                title={
                  defaults.data.qa_view_group_id
                    ? `${groups.data?.find((group) => group.id === defaults.data.qa_view_group_id)?.name ?? 'Default group'} can view new projects`
                    : 'QA can view new projects'
                }
                body="Adds an explicit View rule for the selected group. Membership is never inferred from a role."
                checked={Boolean(defaults.data.qa_view_group_id)}
                disabled={
                  !canSetDefaults ||
                  setDefaults.isPending ||
                  !groups.data?.some((g) => g.name === 'QA')
                }
                onCheckedChange={(checked) =>
                  setDefaults.mutate(
                    checked
                      ? (groups.data?.find((g) => g.name === 'QA')?.id ?? null)
                      : null,
                  )
                }
              />
              <label className="flex items-center gap-3 text-label text-fg-muted">
                Default view group
                <select
                  aria-label="Default view group"
                  className="rounded border border-border bg-surface px-2 py-1 text-fg"
                  value={defaults.data.qa_view_group_id ?? ''}
                  disabled={!canSetDefaults || setDefaults.isPending}
                  onChange={(event) =>
                    setDefaults.mutate(event.target.value || null)
                  }
                >
                  <option value="">No default group</option>
                  {(groups.data ?? []).map((group) => (
                    <option key={group.id} value={group.id}>
                      {group.name}
                    </option>
                  ))}
                </select>
              </label>
              <CheckRow
                title="Client portal is off until the lead turns it on"
                checked={defaults.data.client_portal_off}
                disabled
                onCheckedChange={() => {}}
              />
            </div>
          ) : defaults.isError ? (
            <p role="alert">Could not load project defaults.</p>
          ) : (
            <Muted>Loading project defaults…</Muted>
          )}
        </Section>
        {pending.length ? (
          <Section title="Access requests" count={pending.length}>
            <Table aria-label="Pending access requests">
              <TableHeader>
                <TableRow>
                  <TableHead>Person</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Decision</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pending.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell>{r.name}</TableCell>
                    <TableCell>
                      {projects.data?.find((p) => p.id === r.project_id)?.title}
                    </TableCell>
                    <TableCell>{r.reason}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          disabled={decide.isPending}
                          onClick={() =>
                            decide.mutate({ requestId: r.id, approve: true })
                          }
                        >
                          Approve edit access
                        </Button>
                        <Button
                          size="sm"
                          variant="quiet"
                          disabled={decide.isPending}
                          onClick={() =>
                            decide.mutate({ requestId: r.id, approve: false })
                          }
                        >
                          Deny
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Section>
        ) : null}
        {requests.isError ? (
          <p role="alert">Access requests are unavailable.</p>
        ) : null}
      </SettingsBody>
      {dialog ? (
        <RuleDialog
          projects={manageableProjects}
          groups={groups.data ?? []}
          people={people.data ?? []}
          rule={dialog.kind === 'edit' ? dialog.rule : undefined}
          busy={save.isPending || remove.isPending}
          onClose={() => setDialog(null)}
          onSave={(input) => save.mutate(input)}
          onRemove={
            dialog.kind === 'edit'
              ? () => remove.mutate(dialog.rule.id)
              : undefined
          }
        />
      ) : null}
    </>
  )
}

function RuleDialog({
  projects,
  groups,
  people,
  rule,
  busy,
  onClose,
  onSave,
  onRemove,
}: {
  projects: { id: string; title: string }[]
  groups: WorkspaceGroup[]
  people: { user_id: string; name: string; role: string }[]
  rule?: ProjectAccessRule
  busy: boolean
  onClose: () => void
  onSave: (input: Parameters<typeof setProjectAccessRule>[1]) => void
  onRemove?: () => void
}) {
  const [projectId, setProjectId] = useState(
    rule?.project_id ?? projects.at(0)?.id ?? '',
  )
  const [kind, setKind] = useState<'group' | 'user'>(
    rule?.user_id ? 'user' : 'group',
  )
  const [principalId, setPrincipalId] = useState(
    rule?.group_id ?? rule?.user_id ?? '',
  )
  const [flags, setFlags] = useState<ProjectPermissions>(
    rule ?? {
      can_view: true,
      can_edit: false,
      can_review: false,
      client_portal: false,
      can_manage: false,
    },
  )
  return (
    <Dialog open onOpenChange={(open) => (open ? undefined : onClose())}>
      <DialogContent className="w-[min(520px,calc(100vw-32px))]">
        <DialogHeader
          title={rule ? 'Edit access rule' : 'Add access rule'}
          description="Changes take effect on the next request and are audited. Group membership is explicit."
        />
        <DialogBody>
          <Field label="Project">
            <select
              aria-label="Project"
              disabled={Boolean(rule)}
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Principal type">
            <select
              aria-label="Principal type"
              disabled={Boolean(rule)}
              value={kind}
              onChange={(e) => {
                setKind(e.target.value === 'user' ? 'user' : 'group')
                setPrincipalId('')
              }}
            >
              <option value="group">Group</option>
              <option value="user">Person</option>
            </select>
          </Field>
          <Field label={kind === 'group' ? 'Group' : 'Person'}>
            <select
              aria-label={kind === 'group' ? 'Group' : 'Person'}
              disabled={Boolean(rule)}
              value={principalId}
              onChange={(e) => setPrincipalId(e.target.value)}
            >
              <option value="">Choose…</option>
              {kind === 'group'
                ? groups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))
                : people.map((p) => (
                    <option key={p.user_id} value={p.user_id}>
                      {p.name}
                    </option>
                  ))}
            </select>
          </Field>
          {[
            ...columns,
            { key: 'can_manage', label: 'Manage project access' } as const,
          ].map((c) => (
            <label key={c.key} className="flex items-center gap-2 text-body">
              <input
                type="checkbox"
                checked={flags[c.key]}
                onChange={(e) =>
                  setFlags({ ...flags, [c.key]: e.target.checked })
                }
              />
              {c.label}
            </label>
          ))}
          <Muted>
            Edit and Review include reading. Management is separate. Workspace
            capabilities remain the upper bound.
          </Muted>
        </DialogBody>
        <DialogFooter>
          {onRemove ? (
            <Button variant="danger" disabled={busy} onClick={onRemove}>
              Remove rule
            </Button>
          ) : null}
          <DialogClose render={<Button />}>Cancel</DialogClose>
          <Button
            variant="primary"
            disabled={busy || !projectId || !principalId}
            onClick={() =>
              onSave({
                projectId,
                principal:
                  kind === 'group'
                    ? { kind: 'group', groupId: principalId }
                    : { kind: 'user', userId: principalId },
                ...flags,
              })
            }
          >
            Save rule
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
