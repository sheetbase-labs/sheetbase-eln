import { randomUUID } from 'node:crypto'
import { expect, test } from 'playwright/test'

import { signInAsDesignUser } from '../visual/sign-in'

// Real Settings routes and canonical RPCs; a partial design seed is sufficient
// for interaction coverage, but not the full Settings parity acceptance exit.
test.use({
  baseURL: 'http://127.0.0.1:3200',
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 2,
})

test('owner changes explicit group membership and independent access flags', async ({
  page,
}) => {
  test.setTimeout(60_000)
  const name = `SET02 browser ${randomUUID()}`
  await signInAsDesignUser(page, '00000000-0000-4000-8000-000000000310')
  await page.goto('/settings/members')
  await expect(
    page.getByRole('table', { name: 'Members', exact: true }),
  ).toContainText('Anna B.')
  await page.getByRole('button', { name: 'Switch workspace' }).click()
  await page
    .getByRole('menuitem', { name: 'Process Development', exact: true })
    .click()
  await expect(
    page.getByRole('button', { name: 'Switch workspace' }),
  ).toContainText('Process Development')
  await page.getByRole('button', { name: 'Groups', exact: true }).click()
  const groups = page.getByRole('dialog', { name: 'Workspace groups' })
  await groups.getByLabel('New group name', { exact: true }).fill(name)
  await groups.getByRole('button', { name: 'Create group' }).click()
  await expect(groups.getByRole('option', { name, exact: true })).toBeAttached()
  await groups.getByLabel('Group to manage').selectOption({ label: name })
  await groups.getByRole('checkbox', { name: 'Anna B.', exact: true }).click()
  await expect(
    groups.getByRole('checkbox', { name: 'Anna B.', exact: true }),
  ).toBeChecked()
  await groups.getByRole('button', { name: 'Done', exact: true }).click()
  const anna = page
    .getByRole('table', { name: 'Members', exact: true })
    .getByRole('row')
    .filter({ hasText: 'Anna B.' })
  await expect(anna).toContainText(name)

  await page.goto('/settings/access')
  await page.getByRole('button', { name: 'Add rule', exact: true }).click()
  const dialog = page.getByRole('dialog', { name: 'Add access rule' })
  await dialog
    .getByLabel('Group', { exact: true })
    .selectOption({ label: name })
  await dialog.getByRole('checkbox', { name: 'Edit', exact: true }).check()
  await expect(
    dialog.getByRole('checkbox', { name: 'Review', exact: true }),
  ).not.toBeChecked()
  await expect(
    dialog.getByRole('checkbox', { name: 'View', exact: true }),
  ).toBeChecked()
  await expect(
    dialog.getByRole('checkbox', { name: 'Manage project access' }),
  ).not.toBeChecked()
  if (process.env.SET02_CAPTURE_DIR) {
    await page.screenshot({
      path: `${process.env.SET02_CAPTURE_DIR}/set02-access-rule.png`,
    })
  }
  await dialog.getByRole('button', { name: 'Save rule' }).click()
  await expect(dialog).not.toBeVisible()
  const matrix = page.getByRole('table', { name: 'Project access matrix' })
  const row = matrix
    .getByRole('row')
    .filter({ has: page.getByRole('button', { name, exact: true }) })
  await expect(row.getByRole('cell').nth(1)).toContainText(name)
  await expect(row.getByRole('cell').nth(2)).not.toContainText(name)
  await expect(row.getByRole('cell').nth(3)).toContainText(name)
  await expect(row.getByRole('cell').nth(4)).not.toContainText(name)
  await row.getByRole('button', { name, exact: true }).first().click()
  const edit = page.getByRole('dialog', { name: 'Edit access rule' })
  await edit.getByRole('checkbox', { name: 'Review', exact: true }).check()
  await edit.getByRole('button', { name: 'Save rule' }).click()
  await expect(row.getByRole('cell').nth(2)).toContainText(name)
  await row.getByRole('button', { name, exact: true }).first().click()
  await edit.getByRole('button', { name: 'Remove rule' }).click()
  await expect(matrix.getByRole('button', { name, exact: true })).toHaveCount(0)

  await page.goto('/settings/members')
  await page.getByRole('button', { name: 'Groups', exact: true }).click()
  await groups.getByLabel('Group to manage').selectOption({ label: name })
  await groups.getByRole('checkbox', { name: 'Anna B.', exact: true }).click()
  await expect(
    groups.getByRole('checkbox', { name: 'Anna B.', exact: true }),
  ).not.toBeChecked()
  await groups
    .getByRole('button', { name: 'Remove group', exact: true })
    .click()
  await expect(groups.getByRole('alert')).toContainText(
    'will be revoked immediately',
  )
  if (process.env.SET02_CAPTURE_DIR) {
    await page.screenshot({
      path: `${process.env.SET02_CAPTURE_DIR}/set02-group-removal.png`,
    })
  }
  await groups.getByRole('button', { name: 'Confirm removal' }).click()
  await expect(groups.getByRole('option', { name, exact: true })).toHaveCount(0)
})

test('viewer reads explicit groups but cannot manage Settings grants', async ({
  page,
}) => {
  await signInAsDesignUser(page, '00000000-0000-4000-8000-000000000315')
  await page.goto('/settings/members')
  await expect(
    page.getByRole('table', { name: 'Members', exact: true }),
  ).toContainText('Anna B.')
  await page.getByRole('button', { name: 'Switch workspace' }).click()
  await page
    .getByRole('menuitem', { name: 'Process Development', exact: true })
    .click()
  await expect(
    page.getByRole('button', { name: 'Switch workspace' }),
  ).toContainText('Process Development')
  await expect(
    page.getByRole('table', { name: 'Members', exact: true }),
  ).toContainText('Anna B.')
  await expect(
    page.getByRole('button', { name: 'Groups', exact: true }),
  ).toHaveCount(0)
  await expect(
    page.getByRole('button', { name: 'Invite people', exact: true }),
  ).toHaveCount(0)
  await expect(
    page.getByRole('button', { name: 'Manage', exact: true }),
  ).toHaveCount(0)
  await page.goto('/settings/access')
  await expect(
    page.getByRole('table', { name: 'Project access matrix' }),
  ).toContainText('AAV9 process transfer')
  await expect(
    page.getByRole('button', { name: 'Add rule', exact: true }),
  ).toHaveCount(0)
  await expect(page.getByLabel('Default view group')).toBeDisabled()
})
