# Frozen SHEET-03 source checkpoint

This packet preserves the existing task work for the coordinator handoff.
SHEET-03 remains open. No new task, migration, commit, or push was started.
EXP alone owns migration slot 0326 until the next coordinator accepts its checkpoint.

## Source and integration state

The parent branch is GWP/roadmap-4-shell, committed through
2c7d319442fa7436f853d85828b5c8db0f6a9bd2. The parent owns pushing that branch.
This separate checkout must not push the shared feature branch.

SOURCE-PATHS.txt lists 33 current task source and test files. Every file is
byte-identical to that parent commit. There is no unintegrated task source delta.
PARENT-COMPARISON.txt records the comparison, including one obsolete local
fixture now stored under references rather than its original test path.
SHA256SUMS records every payload file's checksum.

The separate checkout's Review route is older than the parent signing changes.
No full Review or Record notebook route is included. The already-integrated
search patch contains only two bounded Review additions against the exact
parent route, preserving signatureMeaning and signing authority. Historical
Record and frozen-review patches are retained under references for provenance.
Do not reapply those patches or replace current shared routes.

references/obsolete-local-0319-anchored-comments.test.ts is not current WIP.
It lacks the parent's explicit project_access grants. Preserve the parent's
current fixture. Do not copy that historical reference into tests/db.

No schema, migration, journal, snapshot, secret, tracker, generated route tree,
SHELL provider, shortcut registry, or keyboard bridge file is included.

## Latest executed checks

The worker command passed eight suites and 180 tests:

```sh
pnpm exec vitest run src/components/comments/comment-panel.test.tsx src/components/comments/comment-thread.test.tsx src/components/sheet/canonical-sheet-workspace.test.tsx src/lib/navigation.test.ts src/lib/search.test.ts src/lib/related-work.test.ts src/lib/ai-retrieval.test.ts src/components/v3/record-picker/record-picker.test.tsx --reporter=dot
```

Worker typecheck and targeted source ESLint passed. The worker's three native
Sheet browser cases passed in 1.0 minute. Parent independently passed seven
consumer suites with 161 tests, source ESLint, and three native cases in
1.1 minutes. Parent independently inspected historical-reply and frozen-focus
captures. The omitted eighth suite, canonical-sheet-workspace.test.tsx, was
rerun by the worker and passed all 19 tests in 3.94 seconds.

Native cases prove persisted live cell/row/range threads, markers after delayed
reads, sort/filter/insertion, Record listing, retired-field history, live reply
owner links in both themes, and exact frozen revision focus. Frozen evidence
and digest remain unchanged with submitted value 4 and live value 77.
Direct links are not canonical search acceptance.

## Known-red canonical search contract

tests/db/sheet-comments.test.ts contains one canonical-search test named
"includes distinct live threads and replies in canonical search with owner
links and honest counts". The latest targeted run failed one test and skipped
ten in 4.33 seconds. Its first api.search query rejects result type comment
with SQLSTATE 22023, invalid result type filter. Later assertions did not run.

Prepared expectations cover distinct real root/reply UUIDs, owner links,
limit-one pagination, total count two, default-search inclusion, outsider
exclusion, and archived flags. This test covers live recordless threads only.
Frozen destinations, current SET object/project denial before counts, hidden
embedding privacy, and mixed permitted/denied pagination still need contracts
and proof. Standalone search_comments does not satisfy the canonical exit.

No canonical-search SQL implementation was authored. The inspected local
baseline ends at 0319. Its canonical api.search definition in 0153, destination
patch in 0246, and separate search_comments in 0319 are historical preparation
sources. The next assigned SQL slot needs the exact current parent baseline
and SET can_access_object contract. Preserve 16 result columns and apply owner
visibility before counts, ordering, and pagination.

## Original Record Model upgrade dependency

MDL confirmed client adapters and five red DB contracts, not deployed authority.
Initial Record pins must come from genuine create_model_record after approved
publication. upgrade_record_model_record accepts record ID, version ID, actual
metadata revision, and reason. It accepts no values. Stable canonical field ID
and immutable field_name survive clones. New defaults apply only to new Records.

Existing record-bound composition fixtures are in
tests/db/sheet-composition.test.ts, especially lines 112-367 and 685-754.
They use a record/modelKey parameter, recordId input, canonical sourceFieldId,
and dataset-rooted stable rows. The planned SHEET proof keeps the source Model
Record writable, signs a separate Sheet-containing notebook with the existing
genuine signing fixture, then performs the real explicit pin upgrade.
Compare Record UUID, Instance identity and ACL, row/field identities, comment
anchors, revision_sheet_evidence, and digest before and after. Reload the actual
metadata revision after intervening writes. Do not bypass a signed Record lock.
Definition or Dataset evolution is not this acceptance proof.

No executable MDL integration test was added on guessed server authority.
The genuine upgrade proof awaits MDL's verified implementation checkpoint.
The existing local-row deletion authority gap also remains unproven.

## Blockers and next authority

There is no credential or human-input blocker for this source handoff.
Remaining blockers are the serialized migration queue, exact current baseline
handoff, canonical search SQL and ACL proof, and genuine MDL pin-upgrade proof.
The new coordinator owns independent acceptance, commits, pushes, and task
closure. Known-red contracts must remain labelled pending.
