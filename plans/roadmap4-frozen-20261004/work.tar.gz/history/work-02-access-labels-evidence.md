# WORK-02 independent access labels

Apply this three-path incremental supplement after the exact continuation and attention packets. Both earlier patch files are unchanged. No whole source overwrite, SQL, schema, helper, seed, journal, task tracker or parity annotation is included.

Home Your projects derives its display label from authoritative permission flags: combined Edit + Review is Reviewer; Edit alone is Editor; Review alone is Review only; View alone is Viewer; can_manage is Owner. Readability remains gated by can_view, independently of all labels and legacy access_level. Tests deliberately keep the old projection at editor while varying independent flags, including management without Edit/Review.

The exact 0323 project_members RPC exposes no collaborator capability flags. Its editor-first legacy access_level cannot recover combined Edit + Review. Home People therefore no longer turns that shorthand or a workspace role into a project Review label. It shows the actual scope explicitly, such as Workspace member or Workspace reviewer, retaining genuine Project lead. A null workspace role is Project member, not an inferred reviewer. Actual collaborator capability presentation remains a wire-authority limitation, not permission inferred by the UI.

## Verification

- Focused Home/recents/live-events/workspace-access units: 96 passed across 6 files.
- Scoped source/unit ESLint and pnpm typecheck: passed.
- HOME_TEST_BASE_URL=http://127.0.0.1:3400 pnpm exec playwright test tests/browser/home-ui.test.ts --project=browser --timeout=60000: 8 passed.
- Two new browser tests drive combined and review-only labels in both themes using explicitly intercepted render-contract responses. They also assert populated People labels are workspace-scoped. These fixtures are not real seeded HomeFirstRun acceptance or parity evidence. No inviter/date provenance is inferred.
- Four 2x render-fixture captures were inspected under .amp/in/artifacts/work-02-labels/. Combined Reviewer, Review only, and scoped People labels are readable without clipping or overlap in light and dark.

Original first-run preparation remains unaccepted. The seed owner reports its bounded canonical permission checkpoint now passes custody tests, while complete seed and reseed encounter the queued SET structured-Dataset record-link 42501 denial. That product blocker must be corrected and verified through the existing serialized owner before complete seeded first-run browser/provenance acceptance. No workaround, removed assignment, fabricated foreign key, relaxed tolerance or whole-task closure was introduced here.

All changes are local and uncommitted for parent integration. This supplement does not alter migration ownership or expand the existing task scope.
