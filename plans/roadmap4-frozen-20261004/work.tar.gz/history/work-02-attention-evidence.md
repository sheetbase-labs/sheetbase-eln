# WORK-02 attention and navigation supplement

Apply work-02-attention.patch after the held work-02-continuation.patch. The original ten-path packet remains byte-for-byte unchanged at SHA256 f8f9bbc4bd1304300e1448e0650e543a99c22d0559e5866838d98aa57f54b79f. This four-path supplement is SHA256 5a64ed324f68f5663bec888fe77c4c2f91ddd2d79da5a78941c06b56e5b7c2c2. Its manifest is work-02-attention.paths. Pristine continuation reconstruction passed git apply --check, and applying the supplement reconstructed all four current files byte-for-byte.

## Change and evidence

Home material attention previously linked to /materials without selection, which could open a different lot. It now carries the actual canonical material Record UUID through the existing selected search parameter. The actual material-expiring work-item due date supplies relative expiry copy, including singular/plural, same-day and past-due cases. No expiry, experiment usage or status is fabricated. Wall-calendar date comparison uses the workspace timezone and covers both London DST transitions.

The browser now drives the Home Review action into the submitted revision workspace, not merely checking an href. The material test reads the actual work-item Record ID and verifies the selected lot inspector after clicking MAT-0420. Retry recovery is tested after restoring real API counts. Explicit empty-review rendering is tested with an intercepted empty submission response; that test is state coverage, not real seeded empty-state acceptance or parity evidence.

Executed in /home/user/workspace/work-02-next against the supervised auth-free-disabled server on port 3400:

- Focused Vitest across home-data, work-02, live-events, home-view-tracking and recents: 89 tests passed in 5 files.
- Targeted source/unit ESLint and pnpm typecheck: exit 0.
- HOME_TEST_BASE_URL=http://127.0.0.1:3400 pnpm exec playwright test tests/browser/home-ui.test.ts --project=browser --timeout=60000: 6 passed. Exact real API totals remain 1/2/85/0/8 in both themes. Material selection, submitted-revision navigation, retry recovery and empty-review rendering all passed.
- Light and dark 2x Home screenshots were inspected. MAT-0420 shows lot expires in 6 days and its actual lot title without clipping or overlap. These captures are under .amp/in/artifacts/work-02-attention/.
- Re-executed original Main comparison at 1440x900, London timezone/design clock, populated Summary readiness and unchanged 0.001 tolerance. Both fail: light 44,739 differing pixels, exact ratio 0.034520833333333334; dark 44,670 pixels, exact ratio 0.03446759259259259. Temporary comparison files were removed. No snapshots, references, harness, parity annotations or tolerance edits are bundled.

## Delivery and remaining exits

This is a local, uncommitted supplement for parent integration, not task closure. It has no SET helper/authority changes and does not change the hold on the first packet. Original Main/first-run fidelity remains incomplete. SET own onboarding/assignment integration and browser proof, owner resolution of membership versus opened-project semantics, genuine inviter evidence, dataset-review and analysis/model-recents authority, and canonical identity/scientific/timeline seed gaps remain as reported. Current exact counts do not match the reference 3/2/4/2/8. No tracker, SQL, schema, seed, global styles or other owner's source files changed.
