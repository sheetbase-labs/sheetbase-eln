# WORK-02 continuation checkpoint

This is an incremental patch over the exact parent-current-0319 overlay, not a whole-file transfer. The overlay SHA256 is ebe2a4a02457ec1b1c62a9558177778a6c481945a5bcf43d072d22533fc0fcd0 over base 6f56979970a5107a0bb07e9dac0126b158a2943e. The ten task-only paths are listed in work-02-continuation.paths. git apply --check passed against reconstructed pristine overlay files; applying the patch reconstructed all ten current files byte-for-byte.

## Source changes

- Reviews read actual assigned active submissions, resolve readable records, project titles and submitter identities, show genuine due dates, and navigate to the submitted revision instead of the current Record.
- Dataset attention groups by readable Dataset, with actual missing-unit fields and flag reasons. Material expiry reads canonical personal work-items. Activity shows the real actor and captured field changes.
- First-run projects retain explicit assignment. Open completion separately reads personal canonical project views. The readable project detail route records its canonical UUID through the existing view RPC; only successful non-null tracking invalidates Home recents/open state.
- People labels derive from actual project lead, reviewer or workspace/access roles. Onboarding consumes SET's shared own-user helper with nullable accepted invitation timestamp, never fabricated inviter or project-added provenance. The shared helper is not bundled in this patch.
- Live events invalidate affected workspace-scoped Home keys from durable domain entity/operation facts, not cursor progress, audit reads, presence or self echoes. A 100ms bounded batch coalesces Home keys during replay and is cancelled on disconnect. Existing reset recovery is retained. Access/group/request mutations invalidate effective assignments. SHEET's requested shared-live-comment Record-comments invalidation and regression assertion are included.

## Executed checks

Working directory: /home/user/workspace/work-02-next. Real server: supervised work02next, port 3400, auth-free disabled. Existing migration chain through 0319 was applied using pnpm db:migrate; no reset, new migration, published SQL edit or guard bypass.

- pnpm exec vitest run src/lib/home-data.test.ts src/lib/work-02.test.ts src/lib/live-events.test.ts src/lib/home-view-tracking.test.tsx src/lib/recents.test.ts: 82 tests passed in 5 files.
- Targeted ESLint for the nine owned source/unit paths: exit 0.
- pnpm typecheck: exit 0.
- HOME_TEST_BASE_URL=http://127.0.0.1:3400 pnpm exec playwright test tests/browser/home-ui.test.ts --project=browser --timeout=60000: 3 passed. Independently fetched exact API totals are 1 review, 2 distinct error Datasets, 85 experiments in progress, 0 actual instrument runs in the London day, and 8 Inbox items, in both themes. Actual revision hrefs match submission revision IDs. Missing exact count headers render the explicit error/retry state without zero summaries.
- Original Main full-frame comparisons use the existing state driver plus an explicit populated Summary readiness check, original 1440x900 references, London timezone/design clock, and unchanged maxDiffPixelRatio 0.001. Light fails with 44,719 differing pixels, exact ratio 0.0345054012345679. Dark fails with 44,653 differing pixels, exact ratio 0.03445447530864198. No annotations, snapshots, tolerance, masks or reference changes were transferred. Temporary measurement spec/config were removed.
- Populated light/dark 2x captures and the error state were inspected. No clipping or overlapping content was seen. Reviewable captures are under .amp/in/artifacts/work-02/.

Initial immediate per-event Home invalidation reproduced 429 responses during a historical SSE replay: 86 count batches and 91 audit reads. No new DB change events were found during the preceding five minutes, so an audit-read feedback loop was not established. The bounded Home-only coalescing fixes the executed burst without raising limits or suppressing errors. The regression sends 120 real mutation-shaped events and verifies one affected-key batch plus disconnect cleanup.

## Original exit judgement

WORK-02 remains incomplete. Main does not pass its original parity gate. Original Main expects 3 reviews, 2 distinct error Datasets, 4 experiments, 2 actual instrument runs and 8 Inbox items; current exact authority is 1/2/85/0/8. Current review identities/dates, scientific flag detail, activity timeline and personal recents do not match the immutable board. No counts or scientific values were hardcoded to conceal these differences.

First-run browser/DB acceptance awaits verified SET assignment/onboarding SQL integration. Membership versus opened-project checklist semantics still require the owner's explicit resolution of task-step versus board conflict. Invited-by-Gareth is not available in the approved own-onboarding wire and remains missing authority evidence. Dataset DS-0305 review and analysis/model recents remain unsupported authority dependencies, not seed-only repairs. HomeTriage, InboxEmpty and HelpRecords original acceptance must be combined with their owners' evidence; this checkpoint does not close them or the full task.

No tracker, manifest, seed, global styles, schema, journal, harness, policy/settings or migration files are included. Existing migration repair was preserved. This continuation is local and uncommitted; parent owns integration and the task commit.
