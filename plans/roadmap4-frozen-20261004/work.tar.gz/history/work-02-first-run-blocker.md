# WORK-02 first-run integration blocker

The test-only SET helper and 0323 SQL match the parent's committed SET checkpoint byte-for-byte. Both owned Home patch files retain their previously transferred checksums. No source, helper, seed, SQL, policy or task-tracker correction was made for this investigation.

## Executed setup

Provisioned a new local database named sheetbase_parity_home_first_run, owned by migrator, without dropping or resetting an existing database. Every database-role URL was pointed at that exact isolated database, with SHEETBASE_ENV=test and SHEETBASE_DEV_AUTH_FREE=false, as required by the existing prepareDesignScenario contract.

The supported pnpm db:migrate runner applied the exact integrated chain through 0323 and exited 0 with migrations applied under advisory lock. The existing pnpm db:seed:design then exited 1 with:

```text
seed: design experiments
new row violates row-level security policy for table "sample_events"
```

The seed runner prints each step only after it succeeds. The next step is design sample custody, calling seedDesignSampleCustody. Its first INSERT writes SMP-2210's create custody event under Priya's actual authenticated fixture claims and session, at src/db/seed/design.ts around line 3781. This is not a Home rendering failure or a missing onboarding helper.

## Read-only confirmation

The failed database has the real SMP-2210 record at UUID 00000000-0000-4000-8000-00000000036c, owned by Process workspace 00000000-0000-4000-8000-000000000300 and AAV9 project 00000000-0000-4000-8000-000000000320, with Gareth as created_by_user_id.

- api.project_access contains zero explicit rules for that AAV9 project.
- Under Priya's actual authenticated claims, api.my_project_permissions() returns zero rows.
- internal.can_access_object('record', sample UUID, 'view') and 'edit' both return false.
- The sample custody ledger still has zero rows.

The existing design projects seed creates projects without creator attribution or explicit rules before actor-scoped scientific writes. The new canonical authority deliberately has no owner/admin fallback. DSYS-05 owns the semantic actor/project fixture correction; it was sent these exact findings. No manual grant, role exemption, RLS bypass, removed assignment, fabricated inviter, error suppression or partial-seed acceptance was used.

## Checks and delivery

With the exact integrated SET client helper, Home/recents/live-events/workspace-access focused units pass 91 tests in 6 files and pnpm typecheck exits 0. Home continuation and attention patch SHA256 values remain f8f9bbc4bd1304300e1448e0650e543a99c22d0559e5866838d98aa57f54b79f and 5a64ed324f68f5663bec888fe77c4c2f91ddd2d79da5a78941c06b56e5b7c2c2.

The partial isolated database is retained as failing evidence, not accepted fixture state. First-run browser preparation did not run, and no service was started for that partial scenario. Full first-run acceptance remains blocked on the seed owner's canonical permission preparation, followed by complete seed and real invitation/project-open UI verification. Original task-step versus board semantics and invited-by-Gareth provenance remain unwaived.
