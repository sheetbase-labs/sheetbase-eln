# WORK-02 bounded Home theme-test correction

Apply `work-02-theme.patch` after continuation f8f9bbc4, attention 5a64ed32 and access-labels 654da87a. One path only: `tests/browser/home-ui.test.ts`. Patch SHA256: bb8a2ec71d2eb28c96d6dfd3a1b4a1a5e367cb9ea823745b5d8c07f266efeeba.

## Actual theme source and correction

Authenticated `src/components/theme-provider.tsx` adopts `api.user_preferences.appearance` after the initial cache bootstrap. `src/components/v3/lib/theme.ts` owns the real `sheetbase-theme` key and HTML `.dark` state. The inert `sheetbase.theme` alias is removed from these tests. No production theme implementation changed.

Home tests reuse the Sheet test's ordinary authenticated-client pattern: read the original native preference under Gareth's current Process workspace claims; call `api.set_user_appearance` before each themed navigation; seed the matching cache; assert the final HTML dark class immediately before captures. After every test, restore the native appearance via the same RPC, read it back and assert equality, and close the client in `finally`. Connection setup is restricted to the local disposable database.

## Executed evidence

- Before the correction, a temporary driver forced native Light while the old test prepared cached Dark. The added final HTML assertion failed: class was empty and native rendered preference was Light. Driver cleanup restored and verified the original native preference.
- After correction, the same native-Light-starting driver ran the dark access-label case: **1 passed (8.6s)**. Original native appearance was restored and verified afterward.
- `HOME_TEST_BASE_URL=http://127.0.0.1:3400 pnpm exec playwright test tests/browser/home-ui.test.ts --project=browser --timeout=60000`: **8 passed (46.7s)**. Both light/dark themed families assert final HTML state; each test asserts preference restoration.
- `pnpm typecheck`: PASS.
- The browser file is outside the repository's normal TypeScript project, so direct default ESLint reported a project-inclusion error. With a temporary configuration extending the repository tsconfig and including this browser file and existing source, `pnpm exec eslint tests/browser/home-ui.test.ts --parser-options '{"project":".amp/home-browser-tsconfig.json"}'` and `pnpm exec tsc --noEmit --project .amp/home-browser-tsconfig.json`: both PASS. Temporary config and reproduction driver removed after verification.
- Corrected 2x access-label captures inspected with `view_media`: dark is genuinely charcoal with light foreground; light uses white surfaces and dark foreground. Reviewer, Workspace Member and Workspace Reviewer labels are readable. These are render-contract captures, not original Main parity.

## Limits and delivery

The local app database is the older through-0319 fixture; its exact Home totals were 1 review, 2 distinct datasets, 85 experiments, 0 runs and 8 Inbox items. This does not supersede the parent's updated-0323 database evidence or its positive-review fixture failures. No readable review assertions were weakened, no grants/evidence/SQL/seed/harness files changed, and no 0325 authority was imported.

Previous dark visual claims are withdrawn. Original WORK-02 Main cardinalities/identities, native fresh/reseed policy acceptance and first-run/provenance exits remain open. This is an uncommitted test-only integration packet, not whole-task closure.
